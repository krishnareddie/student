//
//  DairyClass.h
//  ActiveStudent
//
//  Created by Student on 20/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DairyClass : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *dairyTitleLabel;

@property NSString * dairyTitleLabelText;
@end
