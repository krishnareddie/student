//
//  Communication.h
//  ActiveStudent
//
//  Created by Student on 20/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Communication : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *communicationsTitleLabel;
@property NSString *communicationsTitleLabelText;
@end
