//
//  ViewController.m
//  ActiveStudent
//
//  Created by vee source on 14/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import "ViewController.h"
#import "AdminMenu.h"
#import "ParentMenu.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self delegateCall];
    // Do any additional setup after loading the view.
}
-(void)delegateCall{
    self.EMailTF.delegate=self;
    self.passwordTF.delegate=self;
    
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    
    // return NO to disallow editing.
    return YES;
}

// It is important for you to hide the keyboard
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

//@@@@@@@@@@@@@@@  IMP  FOR KEYBOARD HIDING

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
   
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
   }
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
    
    // return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickLoginBTN:(id)sender {
    
    if ([self.EMailTF.text isEqualToString:@"admin"]) {
        
        AdminMenu * adminMenu=[self.storyboard instantiateViewControllerWithIdentifier:@"adminMenuNav"];
        [self presentViewController:adminMenu animated:YES completion:nil];
        
    }else if ([self.EMailTF.text isEqualToString:@"parent"]){
        ParentMenu * parentMenu=[self.storyboard instantiateViewControllerWithIdentifier:@"parentMenuNav"];
        [self presentViewController:parentMenu animated:YES completion:nil];
    }
        
    
}


@end
