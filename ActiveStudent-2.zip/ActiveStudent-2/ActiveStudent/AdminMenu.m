//
//  AdminMenu.m
//  ActiveStudent
//
//  Created by Student on 20/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import "AdminMenu.h"
#import "DairyClass.h"
#import "Holidays.h"
#import "Communication.h"
#import "WriteTo.h"
#import "Options.h"

NSString * labelHeading;

@interface AdminMenu ()
@end

@implementation AdminMenu

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
 #pragma mark - ADMIN DAIRY
    if ([segue.identifier isEqualToString:@"adminDairy"]) {
        
        DairyClass * dairy=[segue destinationViewController];
       labelHeading=@"ENTER DAIRY";
        dairy.dairyTitleLabelText=labelHeading;
    }
#pragma mark - ADMIN HOLIDAYS
    else if ([segue.identifier isEqualToString:@"adminHolidays"]){
        
        Holidays * holidays=[segue destinationViewController];
       labelHeading=@"HOLIDAYS";
        holidays.holidaysTitleLabelText=labelHeading;
        
    }
#pragma mark - ADMIN COMMUNICATIONS
    else if ([segue.identifier isEqualToString:@"adminCommunications"]){
        
        Communication * communications=[segue destinationViewController];
        labelHeading=@"MESSAGES";
        communications.communicationsTitleLabelText=labelHeading;
        
    }
#pragma mark - ADMIN OPTIONS     
    else if ([segue.identifier isEqualToString:@"adminOptions"]){
        
        Options * options=[segue destinationViewController];
        labelHeading=@"SETTINGS";
        options.optionsTitleLabelText=labelHeading;
        
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
