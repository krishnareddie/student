//
//  AppDelegate.h
//  ActiveStudent
//
//  Created by vee source on 14/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

