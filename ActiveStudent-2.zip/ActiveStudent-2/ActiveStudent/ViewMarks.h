//
//  ViewMarks.h
//  ActiveStudent
//
//  Created by Student on 20/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewMarks : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *viewMarksTitleLabel;
@property NSString * viewMarksTitleLabelText;
@end
