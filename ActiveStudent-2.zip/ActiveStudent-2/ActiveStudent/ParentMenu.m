//
//  ParentMenu.m
//  ActiveStudent
//
//  Created by Student on 20/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import "ParentMenu.h"
#import "DairyClass.h"
#import "Holidays.h"
#import "Communication.h"
#import "WriteTo.h"
#import "Options.h"
#import "ViewMarks.h"
#import "UpComingExams.h"

NSString * labelTitle;
@interface ParentMenu ()

@end

@implementation ParentMenu

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
 #pragma mark - PARENT DAIRY
    if ([segue.identifier isEqualToString:@"parentDairy"]) {
        
        DairyClass * dairy=[segue destinationViewController];
        labelTitle=@"DAIRY";
        dairy.dairyTitleLabelText=labelTitle;
    }
#pragma mark - PARENT HOLIDAYS
    else if ([segue.identifier isEqualToString:@"parentHolidays"]){
        
        Holidays * holidays=[segue destinationViewController];
        labelTitle=@"HOLIDAYS";
        holidays.holidaysTitleLabelText=labelTitle;
        
    }
#pragma mark - PARENT COMMUNICATIONS
    else if ([segue.identifier isEqualToString:@"parentCommunication"]){
        
        Communication * communications=[segue destinationViewController];
        labelTitle=@"MESSAGES";
        communications.communicationsTitleLabelText=labelTitle;
        
    }
#pragma mark - PARENT OPTIONS
    
    else if ([segue.identifier isEqualToString:@"parentOptions"]){
        
        Options * options=[segue destinationViewController];
        labelTitle=@"SETTINGS";
        options.optionsTitleLabelText=labelTitle;
        
    }
#pragma mark - PARENT VIEW MARKS
    else if ([segue.identifier isEqualToString:@"parentViewMarks"]){
        
        ViewMarks * viewMarks=[segue destinationViewController];
        labelTitle=@"STUDENT MARKS";
        viewMarks.viewMarksTitleLabelText=labelTitle;
        
    }
    
#pragma mark - PARENT UPCOMING EXAMS
    
    else if ([segue.identifier isEqualToString:@"parentUpComingExams"]){
        
        UpComingExams * upComingExams=[segue destinationViewController];
        labelTitle=@"UPCOMING EXAMS";
        upComingExams.upComingExampleTitleLabelText=labelTitle;
        
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
