//
//  ViewController.h
//  ActiveStudent
//
//  Created by vee source on 14/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *EMailTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;

- (IBAction)onClickLoginBTN:(id)sender;

@end

