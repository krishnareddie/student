//
//  Holidays.h
//  ActiveStudent
//
//  Created by Student on 20/04/16.
//  Copyright © 2016 vee source. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Holidays : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *holidaysTitleLabel;
@property NSString * holidaysTitleLabelText;







@end
